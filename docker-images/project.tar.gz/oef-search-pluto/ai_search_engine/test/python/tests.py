import unittest

from ai_search_engine.test.python.SearchEngineTest import SearchEngineTest

unittest.main() # run all tests
