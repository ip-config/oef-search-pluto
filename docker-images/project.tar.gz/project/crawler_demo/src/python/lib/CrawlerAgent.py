from fake_oef.src.python.lib.FakeAgent import FakeAgent

class CrawlerAgent(FakeAgent):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
