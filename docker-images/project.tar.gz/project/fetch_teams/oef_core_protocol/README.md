# oef-core-protocol
Documentation and protocol buffers files for the oef-core protocol.  
