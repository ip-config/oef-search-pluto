import unittest

from dap_e_r_network.test.python.GraphTest import GraphTest

unittest.main() # run all tests
