import unittest

from utils.test.python.ThreadedWebserverTest import ThreadedWebserverTest

unittest.main() # run all tests
