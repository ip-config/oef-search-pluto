#!/bin/bash -e
./develop-image/scripts/docker-run.sh "$@"

