#!/bin/bash -e

make -j "$@"

