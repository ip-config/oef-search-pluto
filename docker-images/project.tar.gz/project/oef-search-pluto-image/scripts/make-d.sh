#!/bin/bash -e
./develop-image/scripts/docker-make.sh "$@"

