import unittest

from pluto_app.test.python.PlutoTest import PlutoTest
#from dap_api.test.python.QueryTest import QueryTest
#from dap_api.test.python.QueryEmbeddingsTest import QueryEmbeddingsTest
#from dap_api.test.python.DapManagerTest import DapManagerTest

unittest.main() # run all tests
