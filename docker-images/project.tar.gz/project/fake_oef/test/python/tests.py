import unittest

from fake_oef.test.python.FakeOefTest import FakeOefTest

unittest.main() # run all tests
